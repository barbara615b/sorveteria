# Importações principais do Flask
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash

# Importa os Blueprints criados
from routes.clientes import clientes_bp
from routes.sabores import sabores_bp
from routes.pedidos import pedidos_bp

# Importa a função de conexão com o banco de dados
from db import get_db_connection

# Criação do app Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'chave_secreta'  # usada para sessões e mensagens flash

# ===== DECORATOR PARA LOGIN (proteção de rotas) =====
from functools import wraps
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login para acessar essa página.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# ===== ROTA INICIAL =====
@app.route('/')
@login_required
def index():
    return render_template('index.html')  # página inicial protegida por login

# ===== ROTA DE LOGIN =====
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM Funcionarios WHERE email = %s', (email,))
        funcionario = cursor.fetchone()
        cursor.close()
        conn.close()

        # Verifica se o funcionário existe e a senha está correta
        if funcionario and check_password_hash(funcionario['senha'], senha):
            session['funcionario_id'] = funcionario['id_funcionario']
            session['funcionario_nome'] = funcionario['nome']
            flash(f'Bem-vindo, {funcionario["nome"]}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Email ou senha incorretos.', 'danger')

    return render_template('login.html')  # exibe a tela de login

# ===== ROTA DE LOGOUT =====
@app.route('/logout')
@login_required
def logout():
    session.clear()  # limpa a sessão do usuário
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('login'))

# ===== CADASTRO DE FUNCIONÁRIOS (opcional) =====
@app.route('/funcionarios/novo', methods=['GET', 'POST'])
def novo_funcionario():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = request.form['senha']
        senha_hash = generate_password_hash(senha)  # criptografa a senha

        conn = get_db_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO Funcionarios (nome, email, senha) VALUES (%s, %s, %s)', 
                           (nome, email, senha_hash))
            conn.commit()
            flash('Funcionário cadastrado com sucesso!', 'success')
            return redirect(url_for('login'))
        except Exception as err:
            flash(f'Erro ao cadastrar funcionário: {err}', 'danger')
        finally:
            cursor.close()
            conn.close()

    return render_template('funcionario_form.html')

# ===== REGISTRA OS BLUEPRINTS =====
app.register_blueprint(clientes_bp)  # rotas de clientes
app.register_blueprint(sabores_bp)   # rotas de sabores
app.register_blueprint(pedidos_bp)   # rotas de pedidos

# ===== RODA O APP =====
if __name__ == '__main__':
    app.run(debug=True)  # debug=True para facilitar testes durante desenvolvimento
