# Importa a função para gerar hash da senha, garantindo segurança no armazenamento
from werkzeug.security import generate_password_hash 

# Importa o conector para o banco de dados MySQL
import mysql.connector  

# Estabelece conexão com o banco de dados 'Sorveteria' usando usuário, senha e host especificados
conn = mysql.connector.connect(
    host='localhost',        
    user='root',            
    password='Ba162629!',    
    database='Sorveteria'    
)

# Cria um cursor para executar comandos SQL
cursor = conn.cursor() 

# Dados do usuário a ser inserido
nome = "Admin"
email = "admin@sorveteria.com"
senha = "260702"  

# Gera o hash da senha para não salvar a senha em texto claro no banco (mais seguro)
senha_hash = generate_password_hash(senha)

# Executa o comando SQL para inserir o novo funcionário com nome, email e senha já com hash
cursor.execute(
    'INSERT INTO Funcionarios (nome, email, senha) VALUES (%s, %s, %s)', 
    (nome, email, senha_hash)
)

conn.commit()
cursor.close()
conn.close()
print("Admin criado com sucesso!")
