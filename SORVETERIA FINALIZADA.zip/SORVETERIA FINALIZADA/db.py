import mysql.connector
from mysql.connector import Error

# Função para conectar ao banco de dados
def get_db_connection():
    try:
        conn = mysql.connector.connect(
            host='127.0.0.1',         
            port=3306,               
            user='root',            
            password='Ba162629!',    
            database='Sorveteria'    
        )
        if conn.is_connected():
            return conn
    except Error as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        return None
