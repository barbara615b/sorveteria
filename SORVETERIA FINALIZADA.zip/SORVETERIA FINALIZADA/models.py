from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Funcionario(db.Model):
    __tablename__ = 'Funcionarios'
    id_funcionario = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    senha = db.Column(db.String(255), nullable=False)

class Cliente(db.Model):
    __tablename__ = 'Clientes'
    id_cliente = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    telefone = db.Column(db.String(15))

    pedidos = db.relationship('Pedido', backref='cliente', cascade="all, delete", lazy=True)

class Sabor(db.Model):
    __tablename__ = 'Sabores'
    id_sabor = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nome_sabor = db.Column(db.String(100), nullable=False)
    preco = db.Column(db.Numeric(10, 2), nullable=False)
    estoque = db.Column(db.Integer, default=0, nullable=False)

class Pedido(db.Model):
    __tablename__ = 'Pedidos'
    id_pedido = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_cliente = db.Column(db.Integer, db.ForeignKey('Clientes.id_cliente', ondelete='CASCADE'), nullable=False)
    data_pedido = db.Column(db.DateTime, nullable=False)
    valor_total = db.Column(db.Numeric(10, 2))

    itens = db.relationship('ItemPedido', backref='pedido', cascade="all, delete", lazy=True)

class ItemPedido(db.Model):
    __tablename__ = 'ItensPedido'
    id_item = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_pedido = db.Column(db.Integer, db.ForeignKey('Pedidos.id_pedido', ondelete='CASCADE'), nullable=False)
    id_sabor = db.Column(db.Integer, db.ForeignKey('Sabores.id_sabor'), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)

    sabor = db.relationship('Sabor')
