from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import get_db_connection
from functools import wraps

# Cria o blueprint para o módulo de clientes
clientes_bp = Blueprint('clientes', __name__)

# Decorador que exige login para acessar rotas protegidas
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# === LISTAR CLIENTES ===
@clientes_bp.route('/clientes')
@login_required
def listar_clientes():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM Clientes')
    clientes = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('clientes.html', clientes=clientes)

# === CADASTRAR NOVO CLIENTE ===
@clientes_bp.route('/clientes/novo', methods=['GET', 'POST'])
@login_required
def novo_cliente():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        telefone = request.form['telefone']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO Clientes (nome, email, telefone) VALUES (%s, %s, %s)', 
                       (nome, email, telefone))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Cliente criado com sucesso!', 'success')
        return redirect(url_for('clientes.listar_clientes'))

    return render_template('cliente_form.html', cliente=None)

# === EDITAR CLIENTE ===
@clientes_bp.route('/clientes/editar/<int:id_cliente>', methods=['GET', 'POST'])
@login_required
def editar_cliente(id_cliente):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        telefone = request.form['telefone']

        cursor.execute('UPDATE Clientes SET nome=%s, email=%s, telefone=%s WHERE id_cliente=%s',
                       (nome, email, telefone, id_cliente))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Cliente atualizado com sucesso!', 'success')
        return redirect(url_for('clientes.listar_clientes'))

    cursor.execute('SELECT * FROM Clientes WHERE id_cliente=%s', (id_cliente,))
    cliente = cursor.fetchone()
    cursor.close()
    conn.close()

    return render_template('cliente_form.html', cliente=cliente)

# === DELETAR CLIENTE ===
@clientes_bp.route('/clientes/deletar/<int:id_cliente>', methods=['POST'])
@login_required
def deletar_cliente(id_cliente):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM Clientes WHERE id_cliente=%s', (id_cliente,))
    conn.commit()
    cursor.close()
    conn.close()

    flash('Cliente deletado com sucesso!', 'success')
    return redirect(url_for('clientes.listar_clientes'))
