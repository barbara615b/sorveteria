from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import get_db_connection
from functools import wraps

# Cria o blueprint para o módulo de pedidos
pedidos_bp = Blueprint('pedidos', __name__)

# Decorador que exige login para acessar rotas protegidas
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# === LISTAR PEDIDOS ===
@pedidos_bp.route('/pedidos')
@login_required
def listar_pedidos():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Junta pedidos com nomes dos clientes
    cursor.execute("""
        SELECT 
            p.id_pedido,
            c.nome AS cliente,
            p.data_pedido,
            p.valor_total
        FROM Pedidos p
        JOIN Clientes c ON p.id_cliente = c.id_cliente
        ORDER BY p.data_pedido DESC
    """)
    pedidos = cursor.fetchall()

    cursor.close()
    conn.close()
    return render_template('pedido_listar.html', pedidos=pedidos)

# === CADASTRAR NOVO PEDIDO ===
@pedidos_bp.route('/pedidos/novo', methods=['GET', 'POST'])
@login_required
def novo_pedido():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Busca todos os clientes
    cursor.execute("SELECT * FROM Clientes")
    clientes = cursor.fetchall()

    # Busca todos os sabores com nome, preço e estoque
    cursor.execute("SELECT id_sabor, nome_sabor, preco, estoque FROM Sabores")
    sabores = cursor.fetchall()

    if request.method == 'POST':
        id_cliente = request.form['id_cliente']
        total = 0
        itens_validos = []

        # Loop em cada sabor oferecido
        for sabor in sabores:
            sabor_id = str(sabor['id_sabor'])

            # Se o sabor foi selecionado no formulário
            if sabor_id in request.form.getlist('sabores'):
                quantidade_str = request.form.get(f'quantidade_{sabor_id}', '0')
                quantidade = int(quantidade_str) if quantidade_str.isdigit() else 0

                if quantidade > 0:
                    estoque = sabor['estoque']

                    # Verificação de estoque disponível
                    if quantidade > estoque:
                        flash(f"Estoque insuficiente para o sabor '{sabor['nome_sabor']}'. Disponível: {estoque}", "danger")
                        cursor.close()
                        conn.close()
                        return redirect(url_for('pedidos.novo_pedido'))

                    total += sabor['preco'] * quantidade
                    itens_validos.append((sabor['id_sabor'], quantidade))

        # Criação do pedido com valor total
        cursor.execute(
            "INSERT INTO Pedidos (id_cliente, data_pedido, valor_total) VALUES (%s, NOW(), %s)",
            (id_cliente, total)
        )
        pedido_id = cursor.lastrowid

        # Insere os itens do pedido e atualiza estoque
        for sabor_id, quantidade in itens_validos:
            cursor.execute(
                "INSERT INTO ItensPedido (id_pedido, id_sabor, quantidade) VALUES (%s, %s, %s)",
                (pedido_id, sabor_id, quantidade)
            )
            cursor.execute(
                "UPDATE Sabores SET estoque = estoque - %s WHERE id_sabor = %s",
                (quantidade, sabor_id)
            )

        conn.commit()
        cursor.close()
        conn.close()

        flash("Pedido cadastrado com sucesso!", "success")
        return redirect(url_for('pedidos.listar_pedidos'))

    # Método GET: exibe o formulário de cadastro
    cursor.close()
    conn.close()
    return render_template('pedido_form.html', pedido=None, clientes=clientes, sabores=sabores)

# === EDITAR PEDIDO ===
@pedidos_bp.route('/pedidos/editar/<int:id_pedido>', methods=['GET', 'POST'])
@login_required
def editar_pedido(id_pedido):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT * FROM Pedidos WHERE id_pedido = %s", (id_pedido,))
    pedido = cursor.fetchone()

    if not pedido:
        flash("Pedido não encontrado.", "danger")
        return redirect(url_for('pedidos.listar_pedidos'))

    cursor.execute("SELECT * FROM Clientes")
    clientes = cursor.fetchall()

    cursor.execute("SELECT * FROM Sabores")
    sabores = cursor.fetchall()

    # Carrega os itens já existentes no pedido
    cursor.execute("SELECT id_sabor, quantidade FROM ItensPedido WHERE id_pedido = %s", (id_pedido,))
    itens_pedido = cursor.fetchall()
    itens_dict = {str(item['id_sabor']): item['quantidade'] for item in itens_pedido}

    if request.method == 'POST':
        id_cliente = request.form.get('id_cliente')

        # Atualiza cliente do pedido
        cursor.execute("UPDATE Pedidos SET id_cliente = %s WHERE id_pedido = %s", (id_cliente, id_pedido))

        # Remove os itens antigos para reinserir os novos
        cursor.execute("DELETE FROM ItensPedido WHERE id_pedido = %s", (id_pedido,))

        total = 0
        for sabor in sabores:
            sabor_id = str(sabor['id_sabor'])
            if sabor_id in request.form.getlist('sabores'):
                quantidade_str = request.form.get(f'quantidade_{sabor_id}', '0')
                quantidade = int(quantidade_str) if quantidade_str.isdigit() else 0

                if quantidade > 0:
                    total += sabor['preco'] * quantidade

                    cursor.execute(
                        "INSERT INTO ItensPedido (id_pedido, id_sabor, quantidade) VALUES (%s, %s, %s)",
                        (id_pedido, sabor_id, quantidade)
                    )

        cursor.execute("UPDATE Pedidos SET valor_total = %s WHERE id_pedido = %s", (total, id_pedido))

        conn.commit()
        cursor.close()
        conn.close()

        flash("Pedido atualizado com sucesso!", "success")
        return redirect(url_for('pedidos.listar_pedidos'))

    cursor.close()
    conn.close()
    return render_template(
        'pedido_form.html',
        pedido=pedido,
        clientes=clientes,
        sabores=sabores,
        itens_pedido=itens_dict
    )

# === EXCLUIR PEDIDO ===
@pedidos_bp.route('/pedidos/excluir/<int:id_pedido>', methods=['POST'])
@login_required
def excluir_pedido(id_pedido):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Remove o pedido
    cursor.execute("DELETE FROM Pedidos WHERE id_pedido = %s", (id_pedido,))
    conn.commit()

    cursor.close()
    conn.close()

    flash("Pedido excluído com sucesso!", "success")
    return redirect(url_for('pedidos.listar_pedidos'))
