from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from db import get_db_connection  # função para se conectar ao banco de dados
from functools import wraps  # para criar o decorator de login

# Criação do blueprint de sabores
sabores_bp = Blueprint('sabores', __name__)

# Decorator para proteger rotas (exige login)
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# ===== LISTAR SABORES =====
@sabores_bp.route('/sabores')
@login_required
def listar_sabores():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Consulta todos os sabores cadastrados
    cursor.execute('SELECT * FROM Sabores')
    sabores = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('sabores.html', sabores=sabores)

# ===== NOVO SABOR =====
@sabores_bp.route('/sabores/novo', methods=['GET', 'POST'])
@login_required
def novo_sabor():
    if request.method == 'POST':
        nome_sabor = request.form['nome_sabor']
        preco = request.form['preco']
        estoque = request.form['estoque']

        conn = get_db_connection()
        cursor = conn.cursor()

        # Insere o novo sabor
        cursor.execute('INSERT INTO Sabores (nome_sabor, preco, estoque) VALUES (%s, %s, %s)', 
                       (nome_sabor, preco, estoque))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Sabor criado com sucesso!', 'success')
        return redirect(url_for('sabores.listar_sabores'))

    # Exibe o formulário de novo sabor
    return render_template('sabor_form.html', sabor=None)

# ===== EDITAR SABOR =====
@sabores_bp.route('/sabores/editar/<int:id_sabor>', methods=['GET', 'POST'])
@login_required
def editar_sabor(id_sabor):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        nome_sabor = request.form['nome_sabor']
        preco = request.form['preco']
        estoque = request.form['estoque']

        # Atualiza os dados do sabor
        cursor.execute('UPDATE Sabores SET nome_sabor=%s, preco=%s, estoque=%s WHERE id_sabor=%s',
                       (nome_sabor, preco, estoque, id_sabor))
        conn.commit()
        cursor.close()
        conn.close()

        flash('Sabor atualizado com sucesso!', 'success')
        return redirect(url_for('sabores.listar_sabores'))

    # Busca os dados do sabor para preencher o formulário
    cursor.execute('SELECT * FROM Sabores WHERE id_sabor=%s', (id_sabor,))
    sabor = cursor.fetchone()
    cursor.close()
    conn.close()

    return render_template('sabor_form.html', sabor=sabor)

# ===== DELETAR SABOR =====
@sabores_bp.route('/sabores/deletar/<int:id_sabor>', methods=['POST'])
@login_required
def deletar_sabor(id_sabor):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Remove o sabor do banco
    cursor.execute('DELETE FROM Sabores WHERE id_sabor=%s', (id_sabor,))
    conn.commit()
    cursor.close()
    conn.close()

    flash('Sabor deletado com sucesso!', 'success')
    return redirect(url_for('sabores.listar_sabores'))
