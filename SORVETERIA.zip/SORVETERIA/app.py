from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

# Banco e modelos
from db import db
from models import Funcionario

# Blueprints
from routes.clientes import clientes_bp
from routes.sabores import sabores_bp
from routes.pedidos import pedidos_bp
from routes.contato import contato_bp

# Email 
from email_utils import (
    enviar_email_contato,
    enviar_email_pedido,
    enviar_email_boas_vindas,
)

#APP
app = Flask(__name__)
app.config['SECRET_KEY'] = 'chave_secreta'

#Configuração do Banco
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sorveteria.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializa o DB
db.init_app(app)

# Cria tabelas se não existirem
with app.app_context():
    db.create_all()


#DECORATOR PARA LOGIN
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login para acessar essa página.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


#ROTA INICIAL
@app.route('/')
@login_required
def index():
    return render_template('index.html')


#ROTA DE LOGIN
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        funcionario = Funcionario.query.filter_by(email=email).first()

        if funcionario and check_password_hash(funcionario.senha, senha):
            session['funcionario_id'] = funcionario.id_funcionario
            session['funcionario_nome'] = funcionario.nome
            flash(f'Bem-vindo, {funcionario.nome}!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Email ou senha incorretos.', 'danger')

    return render_template('login.html')


#ROTA DE LOGOUT
@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('login'))


#ROTA DE CONTATO
@app.route("/contato", methods=["GET", "POST"])
def contato():
    if request.method == "POST":
        nome = request.form.get("nome")
        setor = request.form.get("setor")
        descricao = request.form.get("descricao")

        if not nome or not setor or not descricao:
            flash("Todos os campos são obrigatórios.", "danger")
            return redirect(url_for("contato"))

        # Monta mensagem para enviar por email
        mensagem = f"""{descricao}
        """

        enviar_email_contato(nome, setor, mensagem)
        flash("Sua solicitação foi enviada com sucesso!", "success")
        return redirect(url_for("contato"))

    return render_template("contato.html")


#REGISTRA BLUEPRINTS
app.register_blueprint(clientes_bp)
app.register_blueprint(sabores_bp)
app.register_blueprint(pedidos_bp)
app.register_blueprint(contato_bp)


#RODA O APP
if __name__ == '__main__':
    app.run(debug=True)
