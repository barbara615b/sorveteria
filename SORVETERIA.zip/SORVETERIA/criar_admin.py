from werkzeug.security import generate_password_hash
from app import app, db
from models import Funcionario

with app.app_context():
    nome = "Admin"
    email = "admin@sorveteria.com"
    senha = "260702"

    if not Funcionario.query.filter_by(email=email).first():
        novo_admin = Funcionario(
            nome=nome,
            email=email,
            senha=generate_password_hash(senha)
        )
        db.session.add(novo_admin)
        db.session.commit()
        print("Admin criado com sucesso!")
    else:
        print("Admin já existe.")
