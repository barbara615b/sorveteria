import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# CONFIGURAÇÕES DO GMAIL
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USER = "sorveteriaadm2025@gmail.com"
SMTP_PASS = "bffq emgi ouoc tmxz"  # senha de app


# FUNÇÃO GENÉRICA COM DEBUG
def enviar_email(assunto, corpo, destinatario):
    try:
        print("Preparando envio de e-mail...")
        print(f"  De: {SMTP_USER}")
        print(f"  Para: {destinatario}")
        print(f"  Assunto: {assunto}")

        msg = MIMEMultipart()
        msg["From"] = SMTP_USER
        msg["To"] = destinatario
        msg["Subject"] = assunto
        msg.attach(MIMEText(corpo, "plain", "utf-8"))

        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.set_debuglevel(1)  # Mostra logs da conversa SMTP
            print("Conectando ao servidor SMTP...")
            server.starttls()
            print("TLS iniciado com sucesso.")
            server.login(SMTP_USER, SMTP_PASS)
            print("Login realizado com sucesso.")
            server.send_message(msg)

        print("Email enviado com sucesso!")

    except Exception as e:
        print("Erro ao enviar email:", e)


# FUNÇÃO: CONTATO
def enviar_email_contato(nome, setor, mensagem):
    assunto = "📩 Nova Solicitação Interna"
    corpo = f"""
    Uma nova solicitação foi registrada no sistema:

    Funcionário: {nome}
    Setor: {setor}
    Mensagem: {mensagem}

    """
    destinatario = "sorveteriaadm2025@gmail.com"  
    enviar_email(assunto, corpo, destinatario)
    

# FUNÇÃO: PEDIDO
def enviar_email_pedido(pedido):
    assunto = f"🍦 Confirmação do Pedido #{pedido.id_pedido}"
    corpo = f"""
    Olá {pedido.cliente.nome},

    Recebemos o seu pedido #{pedido.id_pedido} com sucesso! 🎉

    Valor total: R$ {pedido.valor_total:.2f}

    Nossa equipe já está preparando tudo com carinho para você.  
    Em breve entraremos em contato caso haja alguma atualização.

    Obrigado por escolher a Sorveteria! 💙  
    Atenciosamente,  
    Equipe Sorveteria
    """
    destinatario = pedido.cliente.email
    enviar_email(assunto, corpo, destinatario)



# FUNÇÃO: BOAS-VINDAS
def enviar_email_boas_vindas(cliente):
    assunto = "🎉 Bem-vindo à Sorveteria!"
    corpo = f"""
    Olá {cliente.nome}, seja muito bem-vindo(a)! 🍦💙

    Agora você faz parte da nossa comunidade de clientes.  
    A partir de hoje, poderá aproveitar nossos sabores incríveis  
    e receber novidades, promoções e lançamentos exclusivos.

    Esperamos que sua experiência conosco seja doce e inesquecível!  
    Um grande abraço,  
    Equipe Sorveteria
    """
    enviar_email(assunto, corpo, cliente.email)


