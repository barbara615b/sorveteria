from db import db
from datetime import datetime

# ===== FUNCIONÁRIO =====
class Funcionario(db.Model):
    __tablename__ = "funcionarios"

    id_funcionario = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    senha = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f"<Funcionario {self.nome}>"


# ===== CLIENTE =====
class Clientee(db.Model):
    __tablename__ = "clientes"

    id_cliente = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    telefone = db.Column(db.String(20))

    pedidos = db.relationship("Pedido", backref="cliente", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Cliente {self.nome}>"


# ===== SABOR =====
class Sabor(db.Model):
    __tablename__ = "sabores"

    id_sabor = db.Column(db.Integer, primary_key=True)
    nome_sabor = db.Column(db.String(100), nullable=False)
    preco = db.Column(db.Float, nullable=False)
    estoque = db.Column(db.Integer, default=0)

    itens_pedido = db.relationship("ItemPedido", backref="sabor", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Sabor {self.nome_sabor}>"


# ===== PEDIDO =====
class Pedido(db.Model):
    __tablename__ = "pedidos"

    id_pedido = db.Column(db.Integer, primary_key=True)
    id_cliente = db.Column(db.Integer, db.ForeignKey("clientes.id_cliente"), nullable=False)
    data_pedido = db.Column(db.DateTime, default=datetime.now)
    valor_total = db.Column(db.Float, nullable=False)

    # 🔗 Relacionamento: pedido tem vários itens
    itens = db.relationship("ItemPedido", backref="pedido", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Pedido {self.id_pedido} - Cliente {self.id_cliente}>"


# ===== ITEM DO PEDIDO =====
class ItemPedido(db.Model):
    __tablename__ = "itens_pedido"

    id_item = db.Column(db.Integer, primary_key=True)
    id_pedido = db.Column(db.Integer, db.ForeignKey("pedidos.id_pedido"), nullable=False)
    id_sabor = db.Column(db.Integer, db.ForeignKey("sabores.id_sabor"), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f"<ItemPedido {self.id_item} - Pedido {self.id_pedido}>"
