from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, Clientee
from functools import wraps
from email_utils import enviar_email_boas_vindas

clientes_bp = Blueprint('clientes', __name__)

# Decorador para exigir login
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# LISTAR CLIENTES
@clientes_bp.route('/clientes')
@login_required
def listar_clientes():
    clientes = Clientee.query.all()
    return render_template('clientes.html', clientes=clientes)

# NOVO CLIENTE
@clientes_bp.route('/clientes/novo', methods=['GET', 'POST'])
@login_required
def novo_cliente():
    if request.method == 'POST':
        email = request.form['email']

        # Verifica se já existe cliente com esse e-mail
        cliente_existente = Clientee.query.filter_by(email=email).first()
        if cliente_existente:
            flash("Já existe um cliente com esse e-mail cadastrado.", "danger")
            return redirect(url_for('clientes.novo_cliente'))

        # Cria novo cliente
        cliente = Clientee(
            nome=request.form['nome'],
            email=email,
            telefone=request.form['telefone']
        )
        db.session.add(cliente)
        db.session.commit()

        flash('Cliente criado com sucesso!', 'success')

        # Envia e-mail de boas-vindas
        try:
            enviar_email_boas_vindas(cliente)
        except Exception as e:
            flash(f"Cliente salvo, mas houve erro ao enviar o e-mail: {e}", "warning")

        return redirect(url_for('clientes.listar_clientes'))

    return render_template('cliente_form.html', cliente=None)

# EDITAR CLIENTE
@clientes_bp.route('/clientes/editar/<int:id_cliente>', methods=['GET', 'POST'])
@login_required
def editar_cliente(id_cliente):
    cliente = Clientee.query.get_or_404(id_cliente)
    if request.method == 'POST':
        novo_email = request.form['email']

        # Se o e-mail foi alterado, verificar duplicidade
        cliente_existente = Clientee.query.filter_by(email=novo_email).first()
        if cliente_existente and cliente_existente.id_cliente != cliente.id_cliente:
            flash("Já existe outro cliente com esse e-mail.", "danger")
            return redirect(url_for('clientes.editar_cliente', id_cliente=id_cliente))

        cliente.nome = request.form['nome']
        cliente.email = novo_email
        cliente.telefone = request.form['telefone']
        db.session.commit()

        flash('Cliente atualizado com sucesso!', 'success')
        return redirect(url_for('clientes.listar_clientes'))

    return render_template('cliente_form.html', cliente=cliente)

# DELETAR CLIENTE
@clientes_bp.route('/clientes/deletar/<int:id_cliente>', methods=['POST'])
@login_required
def deletar_cliente(id_cliente):
    cliente = Clientee.query.get_or_404(id_cliente)
    db.session.delete(cliente)
    db.session.commit()
    flash('Cliente deletado com sucesso!', 'success')
    return redirect(url_for('clientes.listar_clientes'))


