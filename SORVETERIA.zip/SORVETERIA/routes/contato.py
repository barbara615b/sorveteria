from flask import Blueprint, render_template, request, redirect, url_for, flash
from email_utils import enviar_email_contato

contato_bp = Blueprint("contato", __name__)

@contato_bp.route("/contato", methods=["GET", "POST"])
def contato():
    if request.method == "POST":
        nome = request.form.get("nome")
        setor = request.form.get("setor")
        descricao = request.form.get("descricao")

        if not nome or not setor or not descricao:
            flash("Todos os campos são obrigatórios.", "danger")
            return redirect(url_for("contato.contato"))

        enviar_email_contato(nome, setor, descricao)

        flash("Solicitação enviada com sucesso!", "success")
        return redirect(url_for("contato.contato"))

    return render_template("contato.html")

