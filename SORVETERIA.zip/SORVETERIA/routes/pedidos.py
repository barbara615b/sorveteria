from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, Pedido, Clientee, Sabor, ItemPedido
from functools import wraps
from datetime import datetime
from email_utils import enviar_email_pedido  

# Blueprint de pedidos
pedidos_bp = Blueprint('pedidos', __name__)


# Decorador para exigir login
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


# LISTAR PEDIDOS
@pedidos_bp.route('/pedidos')
@login_required
def listar_pedidos():
    """
    Lista todos os pedidos, do mais recente para o mais antigo.
    """
    pedidos = Pedido.query.order_by(Pedido.data_pedido.desc()).all()
    return render_template('pedido_listar.html', pedidos=pedidos)


# NOVO PEDIDO
@pedidos_bp.route('/pedidos/novo', methods=['GET', 'POST'])
@login_required
def novo_pedido():
    """
    Cria um novo pedido para um cliente com os sabores selecionados.
    Valida estoque, calcula total e envia e-mail de confirmação.
    """
    clientes = Clientee.query.all()
    sabores = Sabor.query.all()

    if request.method == 'POST':
        id_cliente = request.form.get('id_cliente')
        total = 0
        itens_validos = []

        # Verifica sabores escolhidos
        for sabor in sabores:
            sabor_id = str(sabor.id_sabor)
            if sabor_id in request.form.getlist('sabores'):
                quantidade = int(request.form.get(f'quantidade_{sabor_id}', '0'))
                if quantidade > 0:
                    # Confere estoque
                    if quantidade > sabor.estoque:
                        flash(f"Estoque insuficiente para '{sabor.nome_sabor}'. Disponível: {sabor.estoque}", "danger")
                        return redirect(url_for('pedidos.novo_pedido'))
                    total += float(sabor.preco) * quantidade
                    itens_validos.append((sabor, quantidade))

        # Cria o pedido principal
        pedido = Pedido(
            id_cliente=id_cliente,
            data_pedido=datetime.now(),
            valor_total=total
        )
        db.session.add(pedido)
        db.session.commit() 

        # Cria os itens do pedido e atualiza estoque
        for sabor, quantidade in itens_validos:
            item = ItemPedido(
                id_pedido=pedido.id_pedido,
                id_sabor=sabor.id_sabor,
                quantidade=quantidade
            )
            db.session.add(item)
            sabor.estoque -= quantidade

        db.session.commit()

        # Envia e-mail de confirmação ao cliente
        try:
            enviar_email_pedido(pedido)  
        except Exception as e:
            flash(f"⚠️ Pedido salvo, mas erro ao enviar e-mail: {e}", "warning")

        flash("Pedido cadastrado com sucesso!", "success")
        return redirect(url_for('pedidos.listar_pedidos'))

    return render_template('pedido_form.html', pedido=None, clientes=clientes, sabores=sabores)


# EDITAR PEDIDO
@pedidos_bp.route('/pedidos/editar/<int:id_pedido>', methods=['GET', 'POST'])
@login_required
def editar_pedido(id_pedido):

    pedido = Pedido.query.get_or_404(id_pedido)
    clientes = Clientee.query.all()
    sabores = Sabor.query.all()
    itens_pedido = {item.id_sabor: item.quantidade for item in pedido.itens}

    if request.method == 'POST':
        id_cliente = request.form.get('id_cliente')
        pedido.id_cliente = id_cliente

        # Restaurar estoque dos itens antigos
        for item in pedido.itens:
            item.sabor.estoque += item.quantidade

        # Remover itens antigos
        ItemPedido.query.filter_by(id_pedido=id_pedido).delete()

        # Adicionar novos itens
        total = 0
        for sabor in sabores:
            sabor_id = str(sabor.id_sabor)
            if sabor_id in request.form.getlist('sabores'):
                quantidade = int(request.form.get(f'quantidade_{sabor_id}', '0'))
                if quantidade > 0:
                    if quantidade > sabor.estoque:
                        flash(f"Estoque insuficiente para '{sabor.nome_sabor}'. Disponível: {sabor.estoque}", "danger")
                        return redirect(url_for('pedidos.editar_pedido', id_pedido=id_pedido))
                    total += float(sabor.preco) * quantidade
                    db.session.add(ItemPedido(
                        id_pedido=id_pedido,
                        id_sabor=sabor.id_sabor,
                        quantidade=quantidade
                    ))
                    sabor.estoque -= quantidade

        pedido.valor_total = total
        db.session.commit()
        flash("Pedido atualizado com sucesso!", "success")
        return redirect(url_for('pedidos.listar_pedidos'))

    return render_template('pedido_form.html', pedido=pedido, clientes=clientes, sabores=sabores, itens_pedido=itens_pedido)


# DELETAR PEDIDO
@pedidos_bp.route('/pedidos/deletar/<int:id_pedido>', methods=['POST'])
@login_required
def deletar_pedido(id_pedido):
    """
    Exclui um pedido:
    - Restaura estoque dos itens
    - Remove pedido do banco
    """
    pedido = Pedido.query.get_or_404(id_pedido)

    # Restaurar estoque antes de deletar
    for item in pedido.itens:
        item.sabor.estoque += item.quantidade

    db.session.delete(pedido)
    db.session.commit()
    flash("Pedido deletado com sucesso!", "success")
    return redirect(url_for('pedidos.listar_pedidos'))
