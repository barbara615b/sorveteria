from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models import db, Sabor
from functools import wraps

sabores_bp = Blueprint('sabores', __name__)

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'funcionario_id' not in session:
            flash('Por favor, faça login.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

# LISTAR SABORES
@sabores_bp.route('/sabores')
@login_required
def listar_sabores():
    sabores = Sabor.query.all()
    return render_template('sabores.html', sabores=sabores)

# NOVO SABOR
@sabores_bp.route('/sabores/novo', methods=['GET', 'POST'])
@login_required
def novo_sabor():
    if request.method == 'POST':
        sabor = Sabor(
            nome_sabor=request.form['nome_sabor'],
            preco=request.form['preco'],
            estoque=request.form['estoque']
        )
        db.session.add(sabor)
        db.session.commit()
        flash('Sabor criado com sucesso!', 'success')
        return redirect(url_for('sabores.listar_sabores'))
    return render_template('sabor_form.html', sabor=None)

# EDITAR SABOR
@sabores_bp.route('/sabores/editar/<int:id_sabor>', methods=['GET', 'POST'])
@login_required
def editar_sabor(id_sabor):
    sabor = Sabor.query.get_or_404(id_sabor)
    if request.method == 'POST':
        sabor.nome_sabor = request.form['nome_sabor']
        sabor.preco = request.form['preco']
        sabor.estoque = request.form['estoque']
        db.session.commit()
        flash('Sabor atualizado com sucesso!', 'success')
        return redirect(url_for('sabores.listar_sabores'))
    return render_template('sabor_form.html', sabor=sabor)

# DELETAR SABOR
@sabores_bp.route('/sabores/deletar/<int:id_sabor>', methods=['POST'])
@login_required
def deletar_sabor(id_sabor):
    sabor = Sabor.query.get_or_404(id_sabor)
    db.session.delete(sabor)
    db.session.commit()
    flash('Sabor deletado com sucesso!', 'success')
    return redirect(url_for('sabores.listar_sabores'))

